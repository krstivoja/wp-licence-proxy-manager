# Gotchas

Traps and limits discovered along the way. Add to this as you build.

## Known from the start

- **The relay only sees what passes through it.** If a builder validates from the
  browser (JS → vendor) or with its own cURL instead of the WordPress HTTP API,
  `pre_http_request` never fires and the request can't be relayed. Phase 0 must
  confirm, per vendor, that license and update calls go through the WP HTTP API.
- **Placeholder typed directly into another site** (no connector) goes straight to
  the vendor, which rejects it. Harmless, but the vault never sees it, so there is
  no alert for that attempt.
- **Key-as-signing-secret.** If a vendor uses the license key to sign its requests
  rather than sending it as data, the site would need the real key to compute the
  signature — can't be hidden. Phase 0 must check this.
- **Update packages may embed the key in the URL.** If so, the response must be
  masked and downloads routed through the vault (Phase 4).
- **Vault is the single point of failure and the crown jewel.** If it's down,
  client sites fall back to the 72 h grace cache. If it's breached, every key is
  exposed — keep it on agency hosting, 2FA, key outside the DB, offsite backups.
- **Grace cache window.** 72 h is a guess; tune once we see how often each builder
  re-validates.
