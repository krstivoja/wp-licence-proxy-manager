# Decisions

Append-only log of non-obvious decisions. Newest at the bottom.

## Gate A — vendor terms (BLOCKING for adapters)

No vendor adapter ships until the vendor has confirmed, in writing, that the
agency may store the key on its own server and relay license + update requests
from client sites using the real client domain.

| Vendor | Asked (date) | Reply (date) | Verdict | Notes |
|--------|--------------|--------------|---------|-------|
| Bricks | _pending_    | —            | —       | agency tier, N client sites |
| Oxygen | _pending_    | —            | —       | agency tier, N client sites |

Phase 0 discovery (sniffing traffic on your own test site with your own key) does
not require Gate A. Shipping an adapter that relays in production does.

## Design decisions

- 2026-09-29 — Site secrets stored **encrypted**, not hashed: the vault needs the
  plaintext to verify request HMACs.
- 2026-09-29 — Masked license bound to one agency-registered URL; the site URL is
  part of the request signature so it can't be altered in transit.
