# Vendor profile: <VENDOR>

Filled in during Phase 0 from the sniffer log and devtools. Every answer changes
the design, so be specific. Use fake/redacted values only.

## Hosts
- License host(s):
- Update host(s):
- Package download host(s):

## License check
- Endpoint path(s):
- HTTP method:
- Goes through the WordPress HTTP API (appears in the sniffer log)?  yes / no
- If no: where does it happen (browser JS, raw cURL, other)?
- Where does the key travel (query string / form field / JSON field / header)?
- Field/param name holding the key:
- Where does the site URL travel (field name)?
- Is the key sent as data, or used to sign the request?  data / signature
- What does a success response look like (status, key fields)?
- Does the response echo the key back anywhere?  yes / no

## Where the builder stores the key locally
- Option name / location:
- Any local format validation on the key (length, charset)?

## Updates
- Update-check endpoint and method:
- Package download URL pattern:
- Is the key embedded in the package URL?  yes / no
- Goes through the WP HTTP API?  yes / no

## Account API
- Does the vendor offer an API that lists activated domains for an account?  yes / no
- If yes: endpoint, auth, and shape:

## Verdict
- [ ] relayable
- [ ] partially relayable (explain what works and what doesn't)
- [ ] not relayable (explain the blocker)

Notes:
