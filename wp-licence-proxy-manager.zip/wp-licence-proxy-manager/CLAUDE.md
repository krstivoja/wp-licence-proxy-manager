# Agency License Vault (wp-licence-proxy-manager): rules for Claude

## Purpose
Keeps agency vendor license keys (Bricks, Oxygen, later others) on the agency
server. Client sites hold only a placeholder and a per-site secret, locked to
one agency-registered URL. License and update requests from client sites are
relayed through the agency server, which inserts the real key before forwarding
to the vendor.

The full design and phase plan is in `PLAN.md`. Read it before writing code.

## Hard rules (non-negotiable)
1. The vendor must always receive the **real key** and the **client's real site
   URL**. Never rewrite site identity, never answer a license check locally,
   never fabricate a vendor response. This tool is key custody with a faithful
   relay, not license spoofing or seat-limit evasion.
2. A masked license works only on its registered URL (plus explicit, non-wildcard
   aliases). Only the agency can set or change that URL. Every relayed call checks
   the signed site-URL header AND the site URL inside the vendor request; any
   mismatch is a 403 and nothing reaches the vendor.
3. Only forward to hosts in a VendorAdapter's allowlist. The relay is never an
   open proxy.
4. The real key must never be written to logs, the client DB, API responses,
   exceptions, or test output.
5. Never modify vendor plugin or theme files. Change what the builder *receives*
   (HTTP filters, options), never what it *is*.
6. No vendor adapter ships without a documented terms approval in `DECISIONS.md`
   (Gate A). Discovery/sniffing in Phase 0 is fine without it.

## Conventions
- PHP 7.4+, WordPress 6.2+. PSR-4, namespace `DPlugins\LicenseVault`.
- `$wpdb->prepare()` on every query; capability + nonce on every admin action;
  escape all output (`esc_html`, `esc_attr`, `esc_url`, `wp_kses`).
- Validate/sanitize input early, escape output late. Use `wp_unslash()` on
  superglobals and read specific keys only.
- Secrets and binding come only from `wp-config.php` constants:
  `ALV_ENCRYPTION_KEY` (vault); `ALV_SITE_ID`, `ALV_SITE_SECRET`,
  `ALV_SITE_URL`, `ALV_VAULT_URL` (connector). Never store these in the DB or
  the repo.
- All URL comparisons go through the shared `DomainNormalizer`.

## Workflow
- Work phase by phase from `PLAN.md`. Finish a phase's acceptance criteria and
  its tests before starting the next.
- Record non-obvious decisions in `DECISIONS.md` and traps in `GOTCHAS.md`.
- Stop and report if a phase's acceptance criteria cannot be met (for example a
  builder turns out not to be relayable).

## Current state
Phase 0 (discovery spike) only. The `tools/alv-sniffer/` mu-plugin is a
throwaway diagnostic to learn how each builder validates and updates. Do NOT
start Phase 1 (vault scaffold) until the vendor profiles in
`docs/vendor-profiles/` are filled in and reviewed.
