# wp-licence-proxy-manager (Agency License Vault)

Keeps an agency's vendor builder license keys (Bricks, Oxygen, later others) on
the agency's own server. Client sites hold only a placeholder and a per-site
secret, locked to one agency-registered URL. License and update requests are
relayed through the agency server, which inserts the real key before forwarding
to the vendor — faithfully, with the client's real domain. The client never sees
the real key, so a stolen client database exposes nothing reusable.

This is **key custody with a faithful relay**, not license spoofing or
seat-limit evasion. The vendor always receives the real key and the real client
domain, and no vendor adapter ships without that vendor's written OK (Gate A in
`DECISIONS.md`).

## Read first
- `CLAUDE.md` — hard rules and conventions for working in this repo.
- `PLAN.md` — full design and the phase-by-phase build plan.
- `DECISIONS.md` — vendor-terms gate and design decisions.
- `GOTCHAS.md` — known limits.

## Status: Phase 0 (discovery spike)
Nothing is built yet. The only code is `tools/alv-sniffer/`, a throwaway
diagnostic that reveals how each builder validates and updates. Fill in
`docs/vendor-profiles/bricks.md` and `oxygen.md` from its output, then move to
Phase 1.

## Layout
```
CLAUDE.md  PLAN.md  DECISIONS.md  GOTCHAS.md
tools/alv-sniffer/      Phase 0 diagnostic mu-plugin (+ README)
docs/vendor-profiles/   bricks.md, oxygen.md (filled in during Phase 0)
vault/                  agency-server plugin (Phase 1+, not yet created)
connector/              client-site mu-plugin (Phase 3+, not yet created)
```
