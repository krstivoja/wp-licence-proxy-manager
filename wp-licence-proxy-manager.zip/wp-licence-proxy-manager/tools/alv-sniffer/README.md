# ALV Sniffer — Phase 0 diagnostic

A throwaway mu-plugin that shows how Bricks and Oxygen talk to their vendors, so
we can decide whether each one can be relayed faithfully. It **observes only** —
it never blocks, rewrites, or relays anything — and it logs **metadata only**
(URLs, methods, header names, body field names). It never writes header or body
values; anything that looks like a key or token is recorded as
`PRESENT(masked)`.

## Use it on a disposable test site only

Not a client site, not production. You'll be entering a real test license, and
even though the sniffer masks values, the point is to keep this contained.

## Install

mu-plugins auto-load, so there's no activation step.

1. Copy `alv-sniffer.php` into the test site's `wp-content/mu-plugins/`
   (create the folder if it doesn't exist).
2. Log in to wp-admin. You should see a blue notice naming the log file path.
   By default it's `alv-sniffer.log` one level **above** the web root; if that
   isn't writable it falls back to `wp-content/alv-sniffer.log`.

## Capture

Do this once with Bricks, then again with Oxygen:

1. Install and activate the builder on the test site.
2. Enter your **test** license key and activate it.
3. Trigger, in order, and note the rough time of each:
   - license activation
   - license deactivation (then re-activate)
   - an update check (Dashboard → Updates, or the plugins screen "check again")
   - a plugin/theme update download, if one is available
4. Open browser devtools → Network while doing the above, and note any license
   calls made **directly from the browser** to a vendor domain. Those won't
   appear in the log (they don't go through WordPress), and that's exactly the
   thing we need to know.

## Read the log

Each record looks like:

```
[2026-10-03 12:00:00Z]
  event: pre_http_request
  method: POST
  url: https://.../activate
  header names:
    - Content-Type
    - User-Agent
  body fields:
    - (form body)
    - license=PRESENT(masked)
    - site_url=string(23)
    - action=string(8)
------------------------------------------------------------
```

Transfer the findings into `../../docs/vendor-profiles/bricks.md` and
`oxygen.md`. The questions those files ask are the ones that decide the design.

## Remove when done

Delete `alv-sniffer.php` from `mu-plugins/` and delete the `.log` file. Nothing
else is left behind — the sniffer creates no options, tables, or cron events.
